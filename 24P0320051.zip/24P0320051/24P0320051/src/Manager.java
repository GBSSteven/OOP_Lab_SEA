public interface Manager {
    public void addEvent();
    public void removeEvent();
    public void displaySchedule();
}
